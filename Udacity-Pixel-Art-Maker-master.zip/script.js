function makeGrid(height, width) {
    const table = document.getElementById("pixelBoard");
    let grid = '';

    // loop for each row
    for (let i = 0; i < height; i++) {
        grid += '<tr class="row-' + i + '">';
        // loop for each cell
        for (let j = 0; j < width; j++) {
            grid += '<td class="cell" id="row-' + i + '_cell-' + j + '"></td>';
        }
        grid += '</tr>';
    }
    // add grid to table element
    table.innerHTML = grid;

    // Add click event to grid cells when the table grid is created
    addClickEventToCells();
}

// gets values for height and width from form and use them to call makrGrid()
function formSubmission() {
    event.preventDefault();
    const width = document.getElementById('EnterWidth').value;
    const height = document.getElementById('EnterHeight').value;
    makeGrid(height, width);
}

// add click events to all the cells
function addClickEventToCells() {
    // on color selection return color:
    const colorPicker = document.getElementById("colorPicker");
    const cells = document.getElementsByClassName('cell');
    for (let i = 0; i < cells.length; i++) {
        cells[i].addEventListener("click", function (event) {
            let clickedCell = event.target;
            clickedCell.style.backgroundColor = colorPicker.value;
        });
    }
}



// on submit of form #sizePicker:
document.getElementById('sizePicker').onsubmit = function () {
    formSubmission();
};

// make a default 20x20 grid.
makeGrid(20, 20);
